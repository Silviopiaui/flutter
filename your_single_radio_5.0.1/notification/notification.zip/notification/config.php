<?php

    $fcm_server_key = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';

    $fcm_topic = 'your_single_radio_topic';

    $onesignal_app_id = 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxxx';
    
    $onesignal_rest_api_key = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';

?>